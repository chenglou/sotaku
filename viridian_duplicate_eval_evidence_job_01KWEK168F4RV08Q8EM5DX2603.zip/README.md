# Viridian Duplicate Eval Evidence

This package is for `job_01KWEK168F4RV08Q8EM5DX2603`, a B200 runner job submitted with `agents: 0` and `limits.max_gens: 1`.

## What Happened

Two fresh eval attempts wrote to the same R2 prefix:

```text
viridian-runner-probes/runs/sotaku-serious-b200-20260701-101911/
```

The first eval wrote from:

```text
/tmp/vd-eval-tvpofe8u
```

The second eval wrote from:

```text
/tmp/vd-eval-pcirlf3z
```

Their time windows overlap. The first eval started at `2026-07-01T10:19:26Z` and was observed through step `20,624` at `2026-07-01T11:14:07Z`. The second eval started at `2026-07-01T10:47:21Z`, from fresh step 0, and was still writing after the API job status had been changed to `cancelled`.

The API logs endpoint returned a platform-side redirect error:

```text
gpu eval server: error following redirect for url (...modal.run/?__modal_function_call_id=...)
```

This suggests Viridian lost contact with one GPU eval server and launched another gen-0 eval while the first eval kept running.

## Files

- `metadata/trace_summary.json` summarizes the two eval attempts.
- `reports/first_eval_report_snapshot.jsonl` is the report from the first eval attempt.
- `reports/second_eval_report_snapshot_after_cancel.jsonl` is the report from the second eval attempt after cancellation.
- `metadata/first_eval_latest_step_20198.json` shows the first eval's checkpoint pointer.
- `metadata/current_latest_after_cancel.json` shows the later lower-step pointer from the second eval.
- `api/logs.json`, `api/job_sanitized.json`, `api/lineage.json`, and `api/series_score.json` are API responses with the job spec omitted.
- `metadata/job_config_without_eval_cmd.json` is the job config summary with `eval_cmd` omitted because it contained presigned URLs.
- `code/eval.py` is the eval script used by both attempts.

The package intentionally excludes checkpoint binaries, presigned URLs, full job specs, and auth config.
